import os

from math import ceil, log
from operator import itemgetter

class MenuItem(object):
   """ Menu item class"""

   def __init__(self, number, text, func=None):
      """ Initialize this item's number, text, and target function """
      self.number = number
      self.text = text
      self.func = func

   def __hash__(self):
      """ Sort MenuItem objects based on their item number """
      return self.number

   def __lt__(self, x):
      """ Make this class sortable """
      return hash(self) < hash(x)

   def __str__(self):
      """ Return the text representation of this menu item """
      return self.text

   def __call__(self, *a, **kw):
      return self.func(*a, **kw)

###

class BaseMenu(object):
   """ Base object for creating a menu """
   prompt = '> '

   def __init__(self, title, prompt=None):
      # Attributes to override
      self.title = title
      if prompt is not None:
         self.prompt = prompt

      # Attributes for storage
      self.menu_items = {}
      self.status_message = None

   def addSelection(self, number, text, func=None):
      """ Add a selection item to this menu """
      self.menu_items[str(number)] = MenuItem(int(number), text, func)

   def addExit(self, text='Back'):
      """ Add the final selection item """
      max_item = max(self.menu_items.values()).number # Max selection #
      exit_item = 10 ** ceil(log(max_item + 1, 10)) - 1 # Make this number all 9s
      if max_item == exit_item: # This item is already taken
         exit_item = exit_item * 10 + 9
      self.addSelection(exit_item, text) # Add this menu selection

   def showMenu(self):
      """ Show a menu with simple options until exit """
      while True:
         # Clear the screen and show header
         self.clearScreen()
         print(self.title + '\n')
         if self.status_message is not None: # Print and then clear any status message
            print(' >> ' + self.status_message + ' <<\n')
            self.status_message = None
         # Show menu options sorted by MenuItem
         for selection, menu_item in sorted(self.menu_items.items(), key=itemgetter(1)):
            print('{}) {}'.format(selection, menu_item))
            exit_item = selection # The last item is "Exit"

         # Prompt for selection
         selection = input('\n' + self.prompt)
         if selection == exit_item:
            break # Exit if exit item was chosen
         if self.selectionMade(selection):
            break # Exit the menu if selectionMade returns true

   def selectionMade(self, selection):
      """ Call the function for the selected item """
      try:
         f = self.menu_items[selection]
      except KeyError:
         self.status_message = 'Invalid selection, please try again.'
      else:
         self.status_message = f()
         print(self.status_message)

   @staticmethod
   def clearScreen(clear_command='cls' if os.name in ('nt', 'ce') else 'clear'):
      """ Clear the screen """
      os.system(clear_command) # clear_command is determined only once