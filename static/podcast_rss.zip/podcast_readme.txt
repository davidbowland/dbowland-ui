INSTALLATION:

Download and install Python. Currently, the latest version is 3.4.3:
https://www.python.org/downloads/release/python-343/

Unzip the contents of podcast_rss.zip into the Python directory. In the case of Python 3.4.3, the default directory is: c:\Python34\

STANDARD USE:

All interaction can be done through the menu system by invoking podcast_menu.bat. Right-click on the menu bar to display Edit options such as copy and paste.

podcast_add.bat has been set up to configure the default download directory to c:\Podcast\. Each podcast will have its own directory created when it is downloaded. podcast_add.bat will also add and download a number of example podcasts.

podcast_update_all.bat will check each podcast for updates and download any new podcasts. Use Windows Scheduler to call this file to automatically trigger podcast updates: http://windows.microsoft.com/en-US/windows/schedule-task

If for some reason a file to be downloaded already exists on the system, it will not be overwritten. This means failed downloads should be deleted from disk, otherwise they will be considered downloaded and never re-downloaded. The "refresh" command line option will re-download missing podcasts from the last four weeks.

COMMAND LINE:

podcast_rss.py was originally designed to be a command line tool. To see command line options invoke: python.exe podcast_rss.py -h