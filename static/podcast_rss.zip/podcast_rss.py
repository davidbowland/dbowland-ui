"""
Podcast RSS manager
David Bowland

Command line options:
python.exe podcast_rss.py -h
Menu system:
python.exe podcast_rss.py
"""

import os
import pickle
import string

from argparse import ArgumentParser # Handles command-line arguments nicely
from datetime import datetime, timedelta, timezone
from urllib.request import urlopen, urlretrieve
from xml.etree import ElementTree # Handy XML parser

###

def normalizePath(path,
                  path_whitelist=set(string.ascii_letters + string.digits + '()[]{}&.,-_ ')):
   """ Removes unrecognized characters from file names """
   return ''.join(filter(path_whitelist.__contains__, path.replace(':', '-')))

###

class Podcast(object):
   """ A single podcast """
   last_guid = None # GUID of most recent download (only used if time conversion malfunctions)
   date_format = '%a, %d %b %Y %H:%M:%S %z' # Date format of podcasts

   def __init__(self, url, target_directory,
                max_history=timedelta(days=8)): # Eight of history usually gives at least one download
      self.url = self.title = url # Podcast URL & title (we'll update the title when we connect to download)
      self.target_directory = target_directory # Directory for downloaded files
      self.last_update = datetime.now(timezone.utc) - max_history # Time of last update check

   def update(self):
      """ Updates podcast local files """
      # We only care about the "channel" field
      with urlopen(self.url) as u:
         channel = ElementTree.parse(u).find('channel')
      # Has the URL been updated?
      for element in channel:
         if element.tag.endswith('new-feed-url'): # Damn namespaces...
            if self.url == element.text:
               break # Found the desired field but no changes
            self.url = element.text # Update our URL
            self.update() # Update from the new feed
            return # This feed is dead to us
      self.title = channel.find('title').text # Remember this podcast's title

      if self.last_guid is None: # Is this our first time with this podcast?
         # If we don't recognize this podcast's date format only download one initial podcast
         itemiter = channel.iterfind('item')
         try:
            datetime.strptime(next(itemiter).find('pubDate').text, self.date_format)
         except ValueError:
            self.last_guid = next(itemiter).find('guid').text

      # Create the output directory if it does not exist
      if not os.path.isdir(self.target_directory):
         os.mkdir(self.target_directory)
      # Download newest items first
      for item in channel.iterfind('item'):
         enclosure = item.find('enclosure')
         if enclosure is None:
            continue # Item is unrecognized if it has no enclosure
         try:
            # Retrieve the date this item was published
            item_time = datetime.strptime(item.find('pubDate').text, self.date_format)
         except ValueError:
            # Invalid date, so download until we hit our known downloaded guid
            if item.find('guid').text == self.last_guid:
               break # We have downloaded all files after (past?) this GUID
         else:
            # Was this item published since our last update? 
            if item_time < self.last_update:
               break # Once we hit a file older than our last update we quit

         url = enclosure.get('url') # URL of file
         # Directory + item title + extension (extension is assumed to exist)
         # This is more descriptive than the item's original name in most cases
         target_path = os.path.join(self.target_directory,
                      normalizePath(item.find('title').text + '.' +
                                       url.rsplit('.', 1)[~0][:3]))
         # Only download files not present -- don't replace/overwrite files
         if not os.path.isfile(target_path):
            print('Downloading {}, {}...'.format(self.title, normalizePath(item.find('title').text)))
            urlretrieve(url, target_path) # Download the URL to disk

      self.last_update = datetime.now(timezone.utc) # Time of last update check
      # Remember the GUID of the first item downloaded
      for item in channel.iterfind('item'):
         if item.find('enclosure') is not None:
            self.last_guid = item.find('guid').text
            break

#

class PodcastDict(dict):
   """ Savable object containing Podcast instances """
   output_path = r'c:\Podcast'

   def __new__(cls, filepath=None):
      # Pickle-created objects don't pass anything to __new__
      if filepath is None:
         return dict.__new__(cls)

      try: # Try to load saved data
         with open(filepath, 'rb') as f:
            return pickle.load(f)
      except FileNotFoundError: # No data to load
         return dict.__new__(cls) # Return a new instance

   def __init__(self, filepath):
      self.filepath = filepath
      super(PodcastDict, self).__init__()

   def save(self):
      with open(self.filepath, 'wb') as f:
         pickle.dump(self, f)

###

class PodcastHandler(object):
   """ Basic interaction object for Podcast instances """
   def __init__(self, data_path, output_path=None):
      self.data = PodcastDict(data_path)
      for item in self.data.values():
         if item.target_directory.startswith('d'):
            item.target_directory = 'c' + item.target_directory[1:]
      if output_path is not None:
         self.data.output_path = output_path
      self.data.save()
      # Create the base output directory if it does not exist
      if not os.path.isdir(self.data.output_path):
         os.mkdir(self.data.output_path)

   def add(self, url, target_directory=None, max_history=timedelta(weeks=1)):
      """ Add a new podcast by URL to RSS feed
      
      target_directory = path to download location for podcast (default created by title of podcast)
      max_history = determines which previous podcasts to initially download (default: datetime.timedelta(weeks=1))
      Note: Unrecognized podcast date fields will cause only one inital podcast download."""
      try:
         p = self.data[url] # If the url is in the dictionary, simply update
      except KeyError:
         if target_directory is None:
            # Determine our target directory based on the podcast's title
            with urlopen(url) as u:
               title = ElementTree.parse(u).find('channel').find('title').text
            target_directory = os.path.join(self.data.output_path, normalizePath(title))
         p = self.data[url] = Podcast(url, target_directory, max_history)
      p.update()
      self.data.save()

   def update(self, url):
      """ Update a single podcast """
      try:
         p = self.data[url]
      except KeyError: # URL not found, so add it
         self.add(url)
      else:
         p.update() # Don't mask KeyErrors in Podcast.update()
         self.data.save()

   def updateAll(self):
      """ Update all podcasts """
      # Call Podcast.update() for each podcast
      for p in self.data.values():
         try:
            p.update()
         except Exception as e:
            print('{}: {}'.format(e.__class__.__name__, e.args))
      self.data.save()

   def refresh(self, url, refresh_period=timedelta(weeks=4)):
      """ Refreshes a podcast up to a certain time

      refresh_period = determines the period to refresh"""
      try:
         p = self.data[url]
      except KeyError: # URL not found, so add it
         self.add(url, max_history=refresh_period)
      else:
         p.last_update = datetime.now(timezone.utc) - refresh_period
         p.last_guid = ''
         p.update() # Don't mask KeyErrors in Podcast.update()
         self.data.save()

   def delete(self, url):
      """ Removes a podcast """
      try:
         del self.data[url]
      except KeyError:
         pass # Data not in the dictionary? That's our goal!
      else:
         self.data.save() # Data was changed so save dictionary

###

# If this program is being accessed from command line then parse any arguments
if __name__ == '__main__':
   parser = ArgumentParser(description='Downloads podcasts through RSS feeds.')
   # The following options can always be used
   parser.add_argument('-db', '--data',
                       help='Path to podcast data, relative or absolute',
                       default='podcast_rss.db')
   parser.add_argument('-l', '--loglevel',
                       help='Minimum level of data to include in log',
                       default='INFO',
                       choices={'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'})
   parser.add_argument('-o', '--output',
                       help='Specify the base output folder (default: {})'.format(PodcastDict.output_path))
   parser.add_argument('-p', '--logpath',
                       help='Path to podcast log, relative or absolute',
                       default='podcast_rss.log')
   # The following options are mutually exclusive
   exclusive_group = parser.add_mutually_exclusive_group()
   exclusive_group.add_argument('-a', '--add',
                       nargs='*', # Accept more than one element after -a
                       help='Add a podcast URL with an optional target directory')
   exclusive_group.add_argument('-d', '--delete',
                       help='Delete a podcast URL')
   exclusive_group.add_argument('-r', '--refresh',
                       help='Refresh a podcast URL')
   exclusive_group.add_argument('-u', '--update',
                       nargs='*', # Accept many URLs after -u
                       help='Specify one or more URLs to update')
   exclusive_group.add_argument('-ua', '--updateall',
                       action='store_true', # Accept -ua without a value
                       help='Update all podcasts')
   options = parser.parse_args() # Parse command-line options

   handler = PodcastHandler(options.data, options.output) # Honor --data and --output options
   if options.add is not None: # --add
      if len(options.add) <= 2:
         handler.add(*options.add)
      else:
         raise ValueError('--add accepts a maximum of two values, URL and (optional) target directory')
   elif options.delete is not None: # --delete
      handler.delete(options.delete)
   elif options.refresh is not None: # --refresh
      handler.refresh(options.refresh)
   elif options.update is not None: # --update
      for url in options.update:
         handler.update(url)
   elif options.updateall: # --updateall
      handler.updateAll()
   elif options.output is None: # No command line arguments so show menu
      from menusystem import BaseMenu

      #

      class SelectionMenu(BaseMenu):
         """ Menu system for selecting a podcast """

         def __init__(self, title, func, success_message, error_message):
            """ Specify the function to call with selection """
            super(SelectionMenu, self).__init__(title) # Call base __init__ function
            self.func = func
            self.success_message = success_message
            self.error_message = error_message
            self.updatePodcastList()

         def updatePodcastList(self):
            # Compile list of current podcasts
            self.menu_items.clear()
            self.podcasts = sorted(handler.data.values(), key=lambda podcast: podcast.title)
            for num, item in enumerate(self.podcasts, 1):
               self.addSelection(num, item.title, self.getFunction(item.url))
            self.addExit()

         def getFunction(self, url):
            def selectionFunction():
               try:
                  self.func(url)
               except:
                  return self.error_message + ' Use command line tools to see full error.'
               else:
                  self.updatePodcastList()
                  return self.success_message
            return selectionFunction

      #

      class MainMenu(BaseMenu):
         """ Main menu """

         def setTitle(self):
            """ Updates the download directory in the menu title """
            self.title = 'Podcast menu\nDownload directory: ' + handler.data.output_path

         def addPodcast(self):
            """ Menu option to add podcast """
            BaseMenu.clearScreen()
            print('Enter podcast URL, including protocol (http://), or leave blank to go back.')
            url = input('\n' + BaseMenu.prompt)
            if not url:
               return 'No podcast added.'
            try:
               handler.add(url)
            except:
               return 'Error adding podcast. Use command line tools to see full error.'
            else:
               return 'Podcast added successfully.'

         def deletePodcast(self):
            """ Menu option to delete podcast """
            delete_menu = SelectionMenu('Delete a podcast', handler.delete,
               'Podcast deleted successfully.','Error deleting podcast.')
            delete_menu.showMenu()

         def updatePodcast(self):
            """ Menu option to delete podcast """
            update_menu = SelectionMenu('Update a podcast', handler.update,
               'Podcast updated successfully.', 'Error updating podcast.')
            update_menu.showMenu()

         def updateAll(self):
            """ Update all podcasts """
            BaseMenu.clearScreen()
            print('Updating all feeds...\n')
            try:
               handler.updateAll()
            except:
               return 'Error updating one or more podcasts. Use command line tools to see full error.'
            else:
               return 'Feed update complete.'

         def changeDirectory(self):
            """ Change default download directory """
            BaseMenu.clearScreen()
            print('Enter default output path for new podcasts URL, including drive (c:\), or leave blank to go back.')
            print('Current directory: ' + handler.data.output_path)
            output_path = input('\n' + BaseMenu.prompt)
            if not output_path:
               return 'Output path not updated.'
            # Update path in data & in title
            handler.data.output_path = output_path
            handler.data.save()
            self.setTitle()
            return 'Output path updated.'

      main_menu = MainMenu('Podcast menu\nDownload directory: ' + handler.data.output_path)
      main_menu.addSelection(1, 'Add RSS feed', main_menu.addPodcast)
      main_menu.addSelection(2, 'Delete RSS feed', main_menu.deletePodcast)
      main_menu.addSelection(3, 'Update RSS feed', main_menu.updatePodcast)
      main_menu.addSelection(4, 'Update all RSS feeds', main_menu.updateAll)
      main_menu.addSelection(5, 'Change default download directory', main_menu.changeDirectory)
      main_menu.addExit('Exit')
      main_menu.showMenu()