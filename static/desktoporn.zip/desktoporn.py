#!/usr/bin/python3
## desktoporn
## David Bowland
## Python 3.4 -- Windows 8.1

import json
import os
import winreg # Only works on Windows

from collections import deque
from contextlib import closing
from ctypes import windll # Only works on Windows
from operator import itemgetter
from random import choice
from time import strftime
from urllib.request import Request, urlopen

user32 = windll.user32 # This is the only part of windll used

###

# Subreddits to search for images
IMAGE_SUBREDDITS = (
 'fractalporn',
 'spaceporn',
 'skyporn',
 'waterporn',
 'earthporn',
 'exposureporn',
 'animalporn',
 'botanicalporn',
 'winterporn',
 'cemeteryporn',
 'cabinporn',
 'villageporn',
 'cityporn',
 'architectureporn',
 'infrastructureporn',
 'abandonedporn',
 'roomporn',
 'machineporn',
 'carporn',
 'bookporn',
 'historyporn',
 )

# Reddit requests a valid user name
username = 'biggerthanexpected'

###

# http://support.microsoft.com/kb/97142
SPI_SETDESKWALLPAPER = 20

###

class RecentBackgrounds(deque):
   """ Controls the most recently displayed backgrounds """
   LOCATION = 'desktoporn.recent'

   def __init__(self, maxlen=25):
      super(RecentBackgrounds, self).__init__(maxlen=maxlen)
      try:
         with open(self.LOCATION) as f:
            self.extend(line.strip() for line in f)
      except FileNotFoundError: # No file available
         pass

   def save(self):
      """ Saves the contents of this object to self.LOCATION """
      with open(self.LOCATION, 'w') as f:
         f.write('\n'.join(self))

recent = RecentBackgrounds()

#

def returnJson(subreddit, username='biggerthanexpected'):
   """ Downloads the JSON data for a subreddit """
   r = Request('http://www.reddit.com/r/' + subreddit + '.json')
   r.add_header('User-Agent', 'u/' + username) # Reddit requests this
   with closing(urlopen(r)) as u:
      return json.loads(u.read().decode('utf-8')) # Expect UTF-8 bytes


def getUrl(data=None):
   """ Returns the highest recognized picture format that hasn't been recently displayed """
   # Get the subreddit data
   if data is None:
      subreddit = choice(IMAGE_SUBREDDITS)
      data = returnJson(subreddit)
   else:
      subreddit = 'provided data'

   # Find the top URL we haven't recently displayed
   for node in data['data']['children']:
      url = node['data']['url']
      if url.endswith(('.jpg', '.bmp', '.png')) and url not in recent:
         recent.append(url)
         recent.save()
         title = node['data']['title']
         with open('desktoporn.txt', 'w') as f:
            f.write(title +
                    '\nfrom ' + subreddit + ' at: ' + url +
                    strftime('\nUpdate time: %x %X'))
         return url, [node['data']['title']]

   # No URL found -- let's change the background anyway
   url = choice(recent) # If "recent" is empty this will error
   with open('desktoporn.txt', 'w') as f:
      f.write('Previously viewed image at: ' + url +
               strftime('\nUpdate time: %x %X'))
   return url, ['Previously viewed image at: ' + url]


def downloadPicture(url, destination=None):
   """ Downloads a picture from a URL to the hard drive """
   if destination is None:
      # In this directory, same extension as original URL
      # user32 prefers absolute paths
      destination = os.path.join(os.getcwd(),
                        'desktoporn.' + url.rsplit('.', 1)[~0])
   with open(destination, 'wb') as i:
      with closing(urlopen(url)) as u:
         i.write(u.read())
   return destination


# If PIL is not installed the image won't be resized
# http://www.pythonware.com/products/pil/
try:
   from PIL import Image, ImageDraw, ImageFont
except ImportError:
   Image = ImageDraw = ImageFont = None
   def formatPicture(path, text):
      pass
else:
   def formatPicture(path, text):
      """ Resizes an image on the hard drive to not be bigger than the desktop """
      # Resize picture to fit screen, scaled
      # http://msdn.microsoft.com/en-us/library/windows/desktop/ms724385%28v=vs.85%29.aspx
      m_size = (user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)) # Get system resolution

      # Open the image and read its size
      i = Image.open(path)
      i_size = i.size

      # Resize the image if we need to
      diff = min(m_size[0] / i_size[0], m_size[1] / i_size[1], 1)
      if diff != 1:
         i_size = [int(diff * x) for x in i_size]
         i = i.resize(i_size, Image.ANTIALIAS)

      # Load the image to write text
      if not text:
         return
      draw = ImageDraw.Draw(i)
      try:
         font = ImageFont.truetype('arial.ttf', 15, encoding='unic')
      except ImportError:
         font = ImageFont.load_default()
      sizes = list(map(font.getsize, text))
      # Text position, vertical
      y = 5 # Top
      # y = i_size[1] - sum(map(itemgetter(1), sizes)) - 5 * len(text) # Bottom
      # x = i_size[0] - max(map(itemgetter(0), sizes)) - 5 # Right
      for line, (this_x, this_y) in zip(text, sizes):
         # Text position, horizontal
         # x = 5 # Left
         x = i_size[0] - this_x - 5 # Right
         for x1 in (x - 1, x, x + 1):
            for y1 in (y - 1, y, y + 1):
               draw.text((x1, y1), line, font=font, fill='#000000')
         draw.text((x, y), line, font=font, fill='#FFFFFF')
         y += this_y + 5
      i.save(path)



def setBackground(path=None, text=None):
   """ Sets the desktop background to an image on the hard drive """
   if path is None:
      url, text = getUrl()
      path = downloadPicture(url)

   # Use image tools if available
   formatPicture(path, text or [])
   # Set background
   # http://support.microsoft.com/kb/97142
   user32.SystemParametersInfoA(SPI_SETDESKWALLPAPER, 0,
   # path must be type "bytes" to be considered null-terminated char *
                                    path.encode('utf-8'), 0)

   # Open the desktop registry key with complete (read & write) access
   wallpaper_key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r'Control Panel\Desktop', 0, winreg.KEY_ALL_ACCESS)
   # Do not tile
   winreg.SetValueEx(wallpaper_key, 'TileWallpaper', 0, winreg.REG_SZ, '0')
   # Centered
   winreg.SetValueEx(wallpaper_key, 'WallpaperStyle', 0, winreg.REG_SZ, '0')
   winreg.CloseKey(wallpaper_key)
   # Force the background to refresh
   # http://msdn.microsoft.com/en-us/library/windows/desktop/bb762118%28v=vs.85%29.aspx
   windll.shell32.SHChangeNotify(int('8000000', 16), int('1000', 16), 0, 0)


class CM(object):
   """ Captures errors in a set area and outputs them to file """
   def __init__(self, path):
      self.path = path
   def __enter__(self):
      pass
   def __exit__(self, *a):
      if any(a): # Was there an error?
         import traceback
         with open(self.path, 'a') as f:
            f.write(strftime('Time of error: %x %X\n'))
            traceback.print_exception(*a, file=f)

if __name__ == '__main__':
   with CM('desktoporn_error.txt'):
      setBackground()